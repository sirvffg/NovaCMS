# QQ群信息解析器 API 文档

## 概述

此api由冷月笙寒开发，用来提取api数据

---

## API 端点

### 1. 短链接参数提取

**端点**: `/get_params.php`

**方法**: `GET` / `POST`

**描述**: 提取QQ群短链接重定向后的完整URL和参数

**参数**:

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| short_url / shortUrl | string | 是 | QQ群短链接 |

**请求示例**:

```bash
# GET 请求
curl -X GET "http://your-domain.com/get_params.php?short_url=https://qm.qq.com/q/xxxxxxxxxx"

# POST 表单请求
curl -X POST http://your-domain.com/get_params.php \
  -d "short_url=https://qm.qq.com/q/xxxxxxxxxx" \
  -H "Content-Type: application/x-www-form-urlencoded"

# POST JSON 请求
curl -X POST http://your-domain.com/get_params.php \
  -H "Content-Type: application/json" \
  -d '{"short_url": "https://qm.qq.com/q/xxxxxxxxxx"}'
```

**成功响应**:

```json
{
    "success": true,
    "error": "",
    "data": {
        "short_url": "https://qm.qq.com/q/xxxxxxxxxx",
        "long_url": "https://qun.qq.com/universal-share/share?authKey=xxx&busi_data=xxx...",
        "params": {
            "authKey": "xxx",
            "busi_data": "xxx",
            "data": "xxx",
            "svctype": "5",
            "tempid": "h5_group_info"
        },
        "decoded_data": {
            "groupCode": "601702362",
            "token": "4yLK5oV3wKlJklFjdq7u...",
            "uin": "2648181326"
        },
        "summary": {
            "群号": "601702362",
            "Token": "4yLK5oV3wKlJklFjdq7u...",
            "UIN": "2648181326",
            "AuthKey": "1VghNShdGUPZlfH0R1iVoT2SYGVpcQ...",
            "ServiceType": "5",
            "TempID": "h5_group_info"
        }
    }
}
```

**失败响应**:

```json
{
    "success": false,
    "error": "请输入有效的URL",
    "data": null
}
```

---

### 2. 完整解析（短链接 + 群信息）

**端点**: `/index.php`

**方法**: `GET` / `POST`

**描述**: 完整的QQ群链接解析流程，包含短链接解析和群信息提取

**参数**:

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| qun_url | string | 是 | QQ群分享链接（短链接或长链接） |
| type | string | 否 | 设置为 `json` 返回JSON格式响应 |

**请求示例**:

```bash
# GET 请求
curl -X GET "http://your-domain.com/index.php?qun_url=https://qm.qq.com/q/xxxxxxxxxx&type=json"

# POST 表单请求
curl -X POST http://your-domain.com/index.php \
  -d "qun_url=https://qm.qq.com/q/xxxxxxxxxx" \
  -H "Content-Type: application/x-www-form-urlencoded"
```

**成功响应**:

```json
{
    "code": 200,
    "msg": "解析成功",
    "data": {
        "group_name": "示例群名称",
        "group_code": "123456789",
        "group_avatar": "https://p.qlogo.cn/gh/123456789/123456789_123456789/100/",
        "member_count": 1000,
        "description": "这是群介绍内容",
        "create_time": "2020-01-01",
        "tags": [
            "IT",
            "信息交流"
        ],
        "member_qqs": [
            "12345678",
            "87654321"
        ],
        "activity": [
            {
                "title": "活跃用户",
                "count": 500,
                "percentage": 50
            }
        ],
        "short_url": "https://qm.qq.com/q/xxxxxxxxxx",
        "long_url": "https://qun.qq.com/universal-share/share?..."
    }
}
```

**失败响应**:

```json
{
    "code": 400,
    "msg": "无法从链接中解析出必要参数，请确保是有效的QQ群分享链接",
    "data": null
}
```

---

## 数据字段说明

### get_params.php 响应字段

| 字段 | 类型 | 说明 |
|------|------|------|
| short_url | string | 原始短链接 |
| long_url | string | 重定向后的完整URL |
| params | object | URL参数对象 |
| params.authKey | string | 认证密钥 |
| params.busi_data | string | 业务数据（Base64编码） |
| params.data | string | 数据参数 |
| params.svctype | string | 服务类型 |
| params.tempid | string | 模板ID |
| decoded_data | object | 解码后的业务数据 |
| decoded_data.groupCode | string | 群号 |
| decoded_data.token | string | 令牌 |
| decoded_data.uin | string | 用户UIN |
| summary | object | 摘要信息（便于查看） |

### index.php 响应字段

| 字段 | 类型 | 说明 |
|------|------|------|
| group_name | string | 群名称 |
| group_code | string | 群号 |
| group_avatar | string | 群头像URL |
| member_count | integer | 群成员数量 |
| description | string | 群介绍 |
| create_time | string | 群创建时间 |
| tags | array | 群标签数组 |
| member_qqs | array | 成员QQ号数组 |
| activity | array | 群活跃度统计数组 |
| activity[].title | string | 活动类型标题 |
| activity[].count | integer | 人数 |
| activity[].percentage | integer | 百分比 |
| short_url | string | 原始短链接 |
| long_url | string | 解析后的长链接 |

---

## API特性

### 跨域支持

所有API端点支持跨域请求：

```
Access-Control-Allow-Origin: *
Access-Control-Allow-Methods: GET, POST, OPTIONS
Access-Control-Allow-Headers: Content-Type, X-Requested-With
```

### JSON 响应格式

所有JSON响应已格式化：

- 中文字符不进行转义 (`JSON_UNESCAPED_UNICODE`)
- 斜杠不进行转义 (`JSON_UNESCAPED_SLASHES`)
- 美化json输出 (`JSON_PRETTY_PRINT`)

---

## 使用示例

### JavaScript

```javascript
// 获取短链接参数
fetch('http://your-domain.com/get_params.php?short_url=' + encodeURIComponent('https://qm.qq.com/q/xxxxxxxxxx'))
  .then(res => res.json())
  .then(data => console.log(data));
```

### Python

```python
import requests

# 获取短链接参数
response = requests.get('http://your-domain.com/get_params.php', params={
    'short_url': 'https://qm.qq.com/q/xxxxxxxxxx'
})
print(response.json())
```

### PHP

```php
// 获取短链接参数
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'http://your-domain.com/get_params.php');
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(['short_url' => 'https://qm.qq.com/q/xxxxxxxxxx']));
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$result = curl_exec($ch);
curl_close($ch);
print_r(json_decode($result, true));
```

---

## 错误代码

| HTTP Code | 说明 |
|-----------|------|
| 200 | 请求成功 |
| 400 | 请求参数错误 |

