<?php
/**
 * QQ群API代理服务器
 * 用于绕过浏览器的同源策略限制
 */

// 设置响应头
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *'); // 允许所有域名访问
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// 处理OPTIONS预检请求
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// 获取请求参数
$authKey = $_GET['authKey'] ?? '';
$busiData = $_GET['busi_data'] ?? '';
$encryptedData = $_GET['data'] ?? '';
$svctype = $_GET['svctype'] ?? '5';
$tempid = $_GET['tempid'] ?? 'h5_group_info';

// 验证必填参数
if (empty($authKey) || empty($busiData) || empty($encryptedData)) {
    echo json_encode([
        'error' => '缺少必填参数',
        'message' => '需要提供 authKey, busi_data, data 参数'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// 构建目标URL
$baseUrl = 'https://qun.qq.com/universal-share/share';
$params = http_build_query([
    'ac' => '1',
    'authKey' => $authKey,
    'busi_data' => $busiData,
    'data' => $encryptedData,
    'svctype' => $svctype,
    'tempid' => $tempid
]);
$url = $baseUrl . '?' . $params;

// 初始化curl
$ch = curl_init();

// 设置curl选项
curl_setopt_array($ch, [
    CURLOPT_URL => $url,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_MAXREDIRS => 5,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_SSL_VERIFYPEER => false, // 跳过SSL证书验证
    CURLOPT_SSL_VERIFYHOST => false,
    CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) QQBrowser/10.8.4451.400 Chrome/98.0.4758.102 Safari/537.36',
    CURLOPT_REFERER => 'https://qun.qq.com/',
    CURLOPT_HTTPHEADER => [
        'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
        'Accept-Language: zh-CN,zh;q=0.9,en;q=0.8',
        'Origin: https://qun.qq.com'
    ]
]);

// 执行请求
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$error = curl_error($ch);
curl_close($ch);

// 处理错误
if ($error) {
    echo json_encode([
        'error' => '请求失败',
        'message' => $error
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// 返回响应
echo json_encode([
    'success' => true,
    'httpCode' => $httpCode,
    'html' => $response
], JSON_UNESCAPED_UNICODE);
