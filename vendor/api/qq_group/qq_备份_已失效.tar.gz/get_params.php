<?php
/**
 * QQ群短链接参数提取工具
 * 自动获取短链接重定向后的完整URL和参数
 */

// 设置JSON响应头和允许跨域
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-Requested-With');

// 处理 OPTIONS 预检请求
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// 处理请求
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 支持 JSON API 请求和表单请求
    $contentType = $_SERVER['CONTENT_TYPE'] ?? '';
    
    if (strpos($contentType, 'application/json') !== false) {
        // JSON API 请求
        $input = json_decode(file_get_contents('php://input'), true);
        $shortUrl = trim($input['short_url'] ?? $input['shortUrl'] ?? '');
    } else {
        // 表单请求
        $shortUrl = trim($_POST['short_url'] ?? '');
    }
    
    $response = getShortUrlParams($shortUrl);
    
    // 直接返回JSON（带格式化）
    echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}

// 支持 GET 请求 API
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $shortUrl = trim($_GET['short_url'] ?? $_GET['shortUrl'] ?? '');
    $response = getShortUrlParams($shortUrl);
    
    // 直接返回JSON（带格式化）
    echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}

/**
 * 获取短链接的重定向URL和参数
 */
function fetchRedirectUrl($shortUrl, &$error) {
    // 先尝试不使用代理
    $response = makeRequest($shortUrl, null);
    
    if ($response['success']) {
        // 检查是否发生了重定向
        if ($response['redirect_count'] > 0 || $response['redirect_url'] !== $shortUrl) {
            return parseRedirectUrl($response['redirect_url'], $response['final_url'], $response['headers']);
        }
    }
    
    // 如果没有重定向，尝试使用代理
    $proxies = loadProxies();
    $lastError = '';
    
    foreach (array_slice($proxies, 0, 5) as $proxy) {
        $response = makeRequest($shortUrl, $proxy);
        
        if ($response['success'] && $response['redirect_count'] > 0) {
            return parseRedirectUrl($response['redirect_url'], $response['final_url'], $response['headers']);
        }
        
        $lastError = $response['error'];
    }
    
    // 最后尝试不使用代理的完整响应
    $response = makeRequest($shortUrl, null);
    
    if ($response['success']) {
        return parseRedirectUrl($response['redirect_url'], $response['final_url'], $response['headers']);
    }
    
    $error = "所有请求都失败了。最后一个错误: " . ($lastError ?: $response['error']);
    return null;
}

/**
 * 加载代理列表
 */
function loadProxies() {
    $proxyFile = __DIR__ . '/proxy.json';
    if (!file_exists($proxyFile)) {
        return [];
    }
    
    $content = file_get_contents($proxyFile);
    $data = json_decode($content, true);
    
    if (!$data || !isset($data['result'])) {
        return [];
    }
    
    // 解析代理格式 "ip:port"
    $proxies = [];
    foreach (explode(',', $data['result']) as $proxy) {
        $proxy = trim($proxy);
        if (preg_match('/^(\d+\.\d+\.\d+\.\d+):(\d+)$/', $proxy, $matches)) {
            $proxies[] = [
                'host' => $matches[1],
                'port' => $matches[2],
                'string' => $matches[1] . ':' . $matches[2]
            ];
        }
    }
    
    return $proxies;
}

/**
 * 发起HTTP请求
 */
function makeRequest($url, $proxy = null) {
    $ch = curl_init($url);
    
    $options = [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => false, // 禁用自动跟随重定向，手动处理
        CURLOPT_HEADER => true,
        CURLOPT_TIMEOUT => 15,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 QQBrowser/11.3.5159.400',
        CURLOPT_HTTPHEADER => [
            'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
            'Accept-Language: zh-CN,zh;q=0.9,en;q=0.8',
            'Accept-Encoding: gzip, deflate, br',
            'Connection: keep-alive',
            'Upgrade-Insecure-Requests: 1',
            'Cache-Control: max-age=0'
        ]
    ];
    
    // 设置代理
    if ($proxy) {
        $options[CURLOPT_PROXY] = $proxy['host'];
        $options[CURLOPT_PROXYPORT] = $proxy['port'];
        $options[CURLOPT_PROXYTYPE] = CURLPROXY_HTTP;
    }
    
    curl_setopt_array($ch, $options);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $redirectUrl = curl_getinfo($ch, CURLINFO_REDIRECT_URL);
    $curlError = curl_error($ch);
    curl_close($ch);
    
    if ($curlError) {
        return [
            'success' => false,
            'error' => $curlError
        ];
    }
    
    // 分离响应头和响应体
    $headerSize = strpos($response, "\r\n\r\n");
    if ($headerSize !== false) {
        $headerText = substr($response, 0, $headerSize);
        $headers = parseHeaders($headerText);
    } else {
        $headers = [];
        $headerText = '';
    }
    
    // 如果没有重定向URL，尝试从响应头中手动解析
    if (empty($redirectUrl) && isset($headers['Location'])) {
        $redirectUrl = $headers['Location'];
    }
    
    // 如果 Location 是相对路径，转换为绝对路径
    if (!empty($redirectUrl) && !preg_match('/^https?:\/\//i', $redirectUrl)) {
        $parsedUrl = parse_url($url);
        $scheme = $parsedUrl['scheme'] ?? 'https';
        $host = $parsedUrl['host'] ?? '';
        $redirectUrl = $scheme . '://' . $host . '/' . ltrim($redirectUrl, '/');
    }
    
    return [
        'success' => true,
        'redirect_url' => $redirectUrl ?: $url,
        'final_url' => $url,
        'headers' => $headers,
        'http_code' => $httpCode,
        'redirect_count' => ($httpCode >= 300 && $httpCode < 400) ? 1 : 0
    ];
}

/**
 * 解析HTTP响应头
 */
function parseHeaders($response) {
    $headers = [];
    $lines = explode("\r\n", $response);
    
    foreach ($lines as $line) {
        if (strpos($line, ':') !== false) {
            list($key, $value) = explode(':', $line, 2);
            $headers[trim($key)] = trim($value);
        }
    }
    
    return $headers;
}

/**
 * 解析重定向URL参数
 */
function parseRedirectUrl($redirectUrl, $finalUrl, $headers) {
    $parsed = parse_url($redirectUrl);
    $params = [];
    
    // 解析URL参数
    if (isset($parsed['query'])) {
        parse_str($parsed['query'], $params);
    }
    
    $result = [
        'short_url' => $finalUrl,
        'long_url' => $redirectUrl,
        'params' => $params,
        'decoded_data' => [],
        'summary' => []
    ];
    
    // 解码 busi_data
    if (!empty($params['busi_data'])) {
        $busiData = base64_decode($params['busi_data']);
        $decoded = json_decode($busiData, true);
        
        if ($decoded) {
            $result['decoded_data'] = $decoded;
            
            // 提取关键信息
            $result['summary']['群号'] = $decoded['groupCode'] ?? '未知';
            $result['summary']['Token'] = substr($decoded['token'] ?? '', 0, 20) . '...';
            $result['summary']['UIN'] = $decoded['uin'] ?? '未知';
        }
    }
    
    // 提取其他参数
    if (!empty($params['authKey'])) {
        $result['summary']['AuthKey'] = substr($params['authKey'], 0, 30) . '...';
    }
    
    $result['summary']['ServiceType'] = $params['svctype'] ?? '未知';
    $result['summary']['TempID'] = $params['tempid'] ?? '未知';
    
    return $result;
}

/**
 * 获取短链接参数
 * @param string $shortUrl 短链接
 * @return array 返回结果 [success => bool, data => array|null, error => string]
 */
function getShortUrlParams($shortUrl) {
    if (empty($shortUrl)) {
        return [
            'success' => false,
            'error' => '请输入短链接',
            'data' => null
        ];
    }
    
    if (!filter_var($shortUrl, FILTER_VALIDATE_URL)) {
        return [
            'success' => false,
            'error' => '请输入有效的URL',
            'data' => null
        ];
    }
    
    $error = '';
    $result = fetchRedirectUrl($shortUrl, $error);
    
    if ($result === null) {
        return [
            'success' => false,
            'error' => $error,
            'data' => null
        ];
    }
    
    return [
        'success' => true,
        'error' => '',
        'data' => $result
    ];
}
