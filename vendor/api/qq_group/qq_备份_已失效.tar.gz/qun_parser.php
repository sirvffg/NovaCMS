<?php
/**
 * QQ群信息解析器 - 无二维码版本
 * 只解析群基本信息、成员和活动数据
 */

// 初始化变量
$result = null;
$error = null;
$jsonContent = '';

/**
 * 解析JSON内容并提取群信息
 */
function parseJsonContent($jsonContent, &$error) {
    $data = json_decode($jsonContent, true);
    
    if (!$data) {
        $error = 'JSON格式错误：' . json_last_error_msg();
        return null;
    }
    
    if (!isset($data['success']) || !$data['success']) {
        $error = 'API返回失败';
        return null;
    }
    
    if (!isset($data['html'])) {
        $error = 'JSON中没有HTML内容';
        return null;
    }
    
    return extractGroupInfo($data['html']);
}

/**
 * 从URL中提取QQ号
 */
function extractQQFromUrl($url) {
    $url = html_entity_decode($url);
    
    // 尝试从t参数提取QQ号 (t=数字)
    if (preg_match('/[?&]t=(\d+)/', $url, $matches)) {
        return $matches[1];
    }
    
    // 尝试从URL中提取数字（备选方案）
    if (preg_match('/(\d{5,})/', $url, $matches)) {
        return $matches[1];
    }
    
    return null;
}

/**
 * 生成QQ头像URL
 */
function getQQAvatarUrl($qq, $size = 100) {
    if (!$qq) return null;
    return "http://q2.qlogo.cn/headimg_dl?dst_uin={$qq}&spec={$size}";
}

/**
 * 从HTML中提取群信息 - 无二维码版本
 */
function extractGroupInfo($html) {
    $result = [
        'group_name' => '',
        'group_code' => '',
        'group_avatar' => '',
        'member_count' => 0,
        'description' => '',
        'create_time' => '',
        'tags' => [],
        'members' => [],
        'member_qqs' => [],
        'activity' => []
    ];
    
    // 提取群名称
    if (preg_match('/<div[^>]*class="group-profile-base__name[^>]*>.*?<div[^>]*>(.*?)<\/div>/s', $html, $matches)) {
        $result['group_name'] = trim(strip_tags($matches[1]));
    }
    
    // 提取群号
    if (preg_match('/群号:\s*(\d+)/', $html, $matches)) {
        $result['group_code'] = $matches[1];
    }
    
    // 提取群头像
    if (preg_match('/<img[^>]*class="group-profile-base__avatar"[^>]*src="([^"]+)"/', $html, $matches)) {
        $result['group_avatar'] = $matches[1];
    }
    
    // 提取成员数
    if (preg_match('/class="group-profile-base__members">(\d+)人<\/div>/', $html, $matches)) {
        $result['member_count'] = intval($matches[1]);
    } elseif (preg_match('/(\d+)人<\/div>/', $html, $matches)) {
        $result['member_count'] = intval($matches[1]);
    }
    
    // 提取群介绍
    if (preg_match('/class="group-profile-base__desc-text[^>]*>(.*?)<\/div>/s', $html, $matches)) {
        $desc = strip_tags($matches[1]);
        $desc = preg_replace('/\s+/', ' ', $desc);
        $result['description'] = trim($desc);
    }
    
    // 提取创建时间
    if (preg_match('/建群时间:\s*([^<]+)/', $html, $matches)) {
        $result['create_time'] = trim($matches[1]);
    }
    
    // 提取标签 (tags) - 支持多种格式
    $tags = [];
    
    // 方法1: 从JSON格式的标签中提取
    if (preg_match('/"tags"\s*:\s*\[([^\]]+)\]/', $html, $matches)) {
        $tagsStr = $matches[1];
        // 解析JSON格式的标签数组
        $tagsStr = trim($tagsStr);
        if (preg_match_all('/"([^"]+)"/', $tagsStr, $tagMatches)) {
            $tags = array_merge($tags, $tagMatches[1]);
        }
    }
    
    // 方法2: 从HTML标签元素中提取
    if (empty($tags)) {
        if (preg_match_all('/<span[^>]*class="[^"]*tag[^"]*"[^>]*>([^<]+)<\/span>/i', $html, $matches)) {
            $tags = array_merge($tags, $matches[1]);
        }
    }
    
    // 方法3: 从标签列表中提取
    if (empty($tags)) {
        if (preg_match_all('/<li[^>]*class="[^"]*tag[^"]*"[^>]*>([^<]+)<\/li>/i', $html, $matches)) {
            $tags = array_merge($tags, $matches[1]);
        }
    }
    
    // 方法4: 从特定样式的标签容器中提取
    if (empty($tags)) {
        if (preg_match('/class="[^"]*tags[^"]*"[^>]*>(.*?)<\/div>/s', $html, $container)) {
            if (preg_match_all('/<[^>]+>([^<]+)<\/[^>]+>/', $container[1], $tagMatches)) {
                $tags = array_merge($tags, $tagMatches[1]);
            }
        }
    }
    
    // 去重并清理标签
    $result['tags'] = array_unique(array_map('trim', $tags));
    $result['tags'] = array_values(array_filter($result['tags']));
    
    // 提取成员头像URL
    if (preg_match_all('/<li[^>]*><img[^>]*src="([^"]+)"[^>]*><\/li>/', $html, $matches)) {
        $result['members'] = $matches[1];
        
        foreach ($matches[1] as $url) {
            $qq = extractQQFromUrl($url);
            if ($qq) {
                $result['member_qqs'][] = $qq;
            }
        }
        $result['member_qqs'] = array_unique($result['member_qqs']);
    }
    
    // 提取活动数据
    if (preg_match_all('/<li[^>]*data-v-2bed4542>.*?<span[^>]*>([^<]+).*?<span[^>]*>(\d+)人.*?<span[^>]*>(\d+)<\/span>\s*%/s', $html, $matches, PREG_SET_ORDER)) {
        foreach ($matches as $match) {
            $result['activity'][] = [
                'title' => trim($match[1]),
                'count' => intval($match[2]),
                'percentage' => intval($match[3])
            ];
        }
    }
    
    return $result;
}

// 格式化数字
function formatNumber($num) {
    return number_format($num);
}