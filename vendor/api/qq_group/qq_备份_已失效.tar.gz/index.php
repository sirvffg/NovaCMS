<?php
/**
 * QQ群信息一键解析器 - 支持短链接和长链接（智能识别）
 * 输入分享链接（短链接或长链接），自动完成代理请求和数据解析
 */

// 初始化变量
$result = null;
$error = null;
$debugInfo = [];

// 自动获取当前域名和协议
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://';
$host = $_SERVER['HTTP_HOST'];
$scriptPath = dirname($_SERVER['SCRIPT_NAME']);
$baseUrl = $protocol . $host . $scriptPath . '/';

$debugInfo['系统信息'] = [
    '协议' => $protocol,
    '域名' => $host,
    '脚本路径' => $scriptPath,
    '基础URL' => $baseUrl
];

// 引入qun_parser.php的解析函数
require_once 'qun_parser.php';

// 检查是否为API请求 (type=json)
$isApi = isset($_REQUEST['type']) && $_REQUEST['type'] === 'json';

// 获取URL参数 (支持POST和GET)
$qunUrl = $_REQUEST['qun_url'] ?? '';

// 处理提交
if (!empty($qunUrl)) {
    $qunUrl = trim($qunUrl);
    $debugInfo['原始链接'] = $qunUrl;
    $debugInfo['链接长度'] = strlen($qunUrl);
    
    // 检查是否包含分散的参数（处理未编码的长链接）
    $hasGlobalParams = isset($_REQUEST['authKey']) && isset($_REQUEST['busi_data']) && isset($_REQUEST['data']);

    // 判断链接类型：短链接（长度小于100）或长链接（长度大于等于100）
    // 注意：如果URL参数被打散导致qun_url变短，但存在全局参数，应视为长链接处理
    if (!$hasGlobalParams && isShortUrlByLength($qunUrl)) {
        $debugInfo['链接类型'] = '短链接 (长度 < 100)';
        
        // 调用get_params.php获取长链接和参数
        $longUrlData = getLongUrlFromShortUrl($qunUrl, $baseUrl, $debugInfo);
        
        if ($longUrlData && isset($longUrlData['long_url'])) {
            $debugInfo['长链接'] = $longUrlData['long_url'];
            $debugInfo['提取的参数'] = $longUrlData['params'] ?? [];
            
            // 从长链接中解析参数
            $params = parseQunUrl($longUrlData['long_url']);
            
            if ($params) {
                $debugInfo['解析参数'] = $params;
                
                // 调用代理获取数据
                $proxyResponse = callProxy($params, $baseUrl, $debugInfo);
                
                if ($proxyResponse && isset($proxyResponse['success']) && $proxyResponse['success']) {
                    // 使用qun_parser.php中的extractGroupInfo函数解析HTML内容
                    $result = extractGroupInfo($proxyResponse['html']);
                    
                    // 添加短链接信息到结果中
                    $result['short_url'] = $qunUrl;
                    $result['long_url'] = $longUrlData['long_url'];
                    
                    $debugInfo['解析成功'] = true;
                    $debugInfo['群名称'] = $result['group_name'];
                    $debugInfo['群号'] = $result['group_code'];
                    $debugInfo['成员数'] = $result['member_count'];
                } else {
                    $error = $proxyResponse['error'] ?? '获取数据失败';
                }
            } else {
                $error = '无法从长链接中解析出必要参数';
                $debugInfo['长链接解析失败'] = $longUrlData['long_url'];
            }
        } else {
            $error = $longUrlData['error'] ?? '获取长链接失败';
        }
    } else {
        // 直接处理长链接
        $debugInfo['链接类型'] = '长链接 (长度 >= 100)';
        
        // 解析链接中的参数
        $params = parseQunUrl($qunUrl);
        
        // 容错处理：如果直接解析失败，尝试从全局请求参数中提取（针对未URL编码的长链接）
        if (!$params) {
            $requiredKeys = ['authKey', 'busi_data', 'data'];
            $tempParams = [];
            $isComplete = true;
            
            foreach ($requiredKeys as $key) {
                if (isset($_REQUEST[$key]) && !empty($_REQUEST[$key])) {
                    $tempParams[$key] = $_REQUEST[$key];
                } else {
                    $isComplete = false;
                    break;
                }
            }
            
            if ($isComplete) {
                $params = $tempParams;
                // 补全可选参数
                $optionalKeys = ['svctype' => '5', 'tempid' => 'h5_group_info', 'ac' => '1'];
                foreach ($optionalKeys as $key => $default) {
                    $params[$key] = $_REQUEST[$key] ?? $default;
                }
                $debugInfo['提示'] = '已自动从URL参数中提取分散的参数（长链接未编码）';
            }
        }
        
        if ($params) {
            $debugInfo['解析参数'] = $params;
            
            // 调用代理获取数据
            $proxyResponse = callProxy($params, $baseUrl, $debugInfo);
            
            if ($proxyResponse && isset($proxyResponse['success']) && $proxyResponse['success']) {
                // 使用qun_parser.php中的extractGroupInfo函数解析HTML内容
                $result = extractGroupInfo($proxyResponse['html']);

                // 添加长链接信息到结果中
                $result['long_url'] = $qunUrl;

                $debugInfo['解析成功'] = true;
                $debugInfo['群名称'] = $result['group_name'];
                $debugInfo['群号'] = $result['group_code'];
                $debugInfo['成员数'] = $result['member_count'];
            } else {
                $error = $proxyResponse['error'] ?? '获取数据失败';
            }
        } else {
            $error = '无法从链接中解析出必要参数，请确保是有效的QQ群分享链接';
        }
    }
} elseif ($isApi || $_SERVER['REQUEST_METHOD'] === 'POST') {
    $error = '请输入QQ群分享链接';
}

// 如果是API请求，输出JSON并退出
if ($isApi) {
    header('Content-Type: application/json; charset=utf-8');
    header('Access-Control-Allow-Origin: *');
    $response = [
        'code' => $result ? 200 : 400,
        'msg' => $error ?: '解析成功',
        'data' => $result
    ];
    echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}

/**
 * 根据链接长度判断是否为短链接
 * 短链接长度小于100，长链接长度大于等于100
 */
function isShortUrlByLength($url) {
    $length = strlen($url);
    
    // 长度小于100的认为是短链接
    if ($length < 100) {
        return true;
    }
    
    // 如果长度大于等于100，但包含短链接域名，也认为是短链接
    $shortDomains = ['qm.qq.com', 'url.cn', 'dwz.cn', 't.cn'];
    foreach ($shortDomains as $domain) {
        if (strpos($url, $domain) !== false) {
            return true;
        }
    }
    
    return false;
}

/**
 * 判断是否是短链接（基于域名）- 保留备用
 */
function isShortUrlByDomain($url) {
    $shortDomains = ['qm.qq.com', 'url.cn', 'dwz.cn', 't.cn', 'qq.com'];
    
    foreach ($shortDomains as $domain) {
        if (strpos($url, $domain) !== false) {
            return true;
        }
    }
    
    return false;
}

/**
 * 调用get_params.php获取长链接
 */
function getLongUrlFromShortUrl($shortUrl, $baseUrl, &$debugInfo) {
    // 构建get_params.php的URL
    $getParamsUrl = $baseUrl . 'get_params.php';
    $debugInfo['get_params URL'] = $getParamsUrl;
    
    // 初始化cURL
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $getParamsUrl,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => http_build_query(['short_url' => $shortUrl]),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/x-www-form-urlencoded'
        ]
    ]);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError = curl_error($ch);
    curl_close($ch);
    
    $debugInfo['get_params HTTP状态'] = $httpCode;
    $debugInfo['get_params原始响应'] = substr($response, 0, 500);
    
    if ($curlError) {
        $debugInfo['get_params错误'] = $curlError;
        return ['error' => '获取长链接失败: ' . $curlError];
    }
    
    if ($httpCode !== 200) {
        return ['error' => "get_params.php返回HTTP {$httpCode}"];
    }
    
    // 解析JSON响应
    $data = json_decode($response, true);
    
    if (!$data) {
        $debugInfo['JSON解析失败'] = '无法解析JSON响应';
        return ['error' => '无法解析JSON响应'];
    }
    
    $debugInfo['JSON解析结果'] = $data;
    
    if ($data['success'] && isset($data['data']['long_url'])) {
        return [
            'short_url' => $shortUrl,
            'long_url' => $data['data']['long_url'],
            'params' => $data['data']['params'] ?? [],
            'decoded_data' => $data['data']['decoded_data'] ?? []
        ];
    }
    
    return ['error' => $data['error'] ?? '获取长链接失败'];
}

/**
 * 从get_params.php返回的HTML中提取长链接
 */
function extractLongUrlFromHtml($html, $shortUrl) {
    $result = [
        'short_url' => $shortUrl,
        'long_url' => null,
        'params' => [],
        'error' => null
    ];
    
    // 方法1: 尝试提取重定向后长链接 - 针对get_params.php的特定HTML结构
    if (preg_match('/<div[^>]*class="result-value"[^>]*>([^<]+https?:\/\/[^<]+)<\/div>/', $html, $matches)) {
        $url = trim($matches[1]);
        // 确保是完整的URL
        if (filter_var($url, FILTER_VALIDATE_URL)) {
            $result['long_url'] = $url;
        }
    }
    
    // 方法2: 查找带有"重定向后长链接"文本的区域
    if (!$result['long_url']) {
        if (preg_match('/重定向后长链接.*?<div[^>]*class="[^"]*"[^>]*>([^<]+https?:\/\/[^<]+)<\/div>/s', $html, $matches)) {
            $url = trim($matches[1]);
            if (filter_var($url, FILTER_VALIDATE_URL)) {
                $result['long_url'] = $url;
            }
        }
    }
    
    // 方法3: 提取所有可能的URL
    if (!$result['long_url']) {
        if (preg_match_all('/https?:\/\/[^\s"\'<>]+/', $html, $matches)) {
            foreach ($matches[0] as $url) {
                // 解码HTML实体
                $url = html_entity_decode($url);
                
                // 排除短链接本身，并确保是完整的URL
                if (strpos($url, 'qun.qq.com/universal-share/share') !== false && 
                    strpos($url, $shortUrl) === false) {
                    $result['long_url'] = $url;
                    break;
                }
            }
        }
    }
    
    // 方法4: 尝试从JavaScript变量中提取
    if (!$result['long_url']) {
        if (preg_match('/var\s+long_url\s*=\s*["\']([^"\']+)["\']/', $html, $matches)) {
            $result['long_url'] = $matches[1];
        }
    }
    
    // 方法5: 如果以上都失败，尝试查找get_params.php结果页面中的任何长链接
    if (!$result['long_url']) {
        if (preg_match('/<div[^>]*class="result-item"[^>]*>.*?<div[^>]*class="result-value"[^>]*>([^<]+https?:\/\/qun\.qq\.com[^<]+)<\/div>/s', $html, $matches)) {
            $url = trim($matches[1]);
            if (filter_var($url, FILTER_VALIDATE_URL)) {
                $result['long_url'] = $url;
            }
        }
    }
    
    // 提取参数（如果存在）
    if ($result['long_url']) {
        // 清理URL（移除可能的HTML标签）
        $result['long_url'] = strip_tags($result['long_url']);
        
        $parsed = parse_url($result['long_url']);
        if (isset($parsed['query'])) {
            parse_str($parsed['query'], $result['params']);
        }
    } else {
        // 记录部分HTML用于调试
        $result['error'] = '无法从响应中提取长链接';
        $result['html_sample'] = substr($html, 0, 1000); // 记录前1000字符用于调试
    }
    
    return $result;
}

/**
 * 从QQ群分享链接中解析参数
 */
function parseQunUrl($url) {
    $parts = parse_url($url);
    if (!isset($parts['query'])) {
        return null;
    }
    
    parse_str($parts['query'], $queryParams);
    
    // 需要的参数列表
    $required = ['authKey', 'busi_data', 'data'];
    $optional = [
        'svctype' => '5',
        'tempid' => 'h5_group_info',
        'ac' => '1'
    ];
    
    $result = [];
    
    // 检查必要参数
    foreach ($required as $key) {
        if (empty($queryParams[$key])) {
            return null;
        }
        $result[$key] = $queryParams[$key];
    }
    
    // 添加可选参数
    foreach ($optional as $key => $default) {
        $result[$key] = $queryParams[$key] ?? $default;
    }
    
    return $result;
}

/**
 * 调用代理API - 自动使用当前域名
 */
function callProxy($params, $baseUrl, &$debugInfo) {
    // 构建完整的代理URL（自动使用当前域名）
    $proxyUrl = $baseUrl . 'proxy.php?' . http_build_query([
        'authKey' => $params['authKey'],
        'busi_data' => $params['busi_data'],
        'data' => $params['data'],
        'svctype' => $params['svctype'],
        'tempid' => $params['tempid']
    ]);
    
    $debugInfo['代理请求URL'] = $proxyUrl;
    
    // 初始化cURL
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $proxyUrl,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        // 强制使用IPv4，避免DNS解析问题
        CURLOPT_IPRESOLVE => CURL_IPRESOLVE_V4,
        // 添加DNS缓存超时设置
        CURLOPT_DNS_CACHE_TIMEOUT => 120,
        // 详细错误信息
        CURLOPT_VERBOSE => true
    ]);
    
    // 创建临时文件存储详细错误信息
    $verbose = fopen('php://temp', 'w+');
    curl_setopt($ch, CURLOPT_STDERR, $verbose);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError = curl_error($ch);
    $curlErrno = curl_errno($ch);
    
    // 获取详细错误信息
    rewind($verbose);
    $verboseLog = stream_get_contents($verbose);
    fclose($verbose);
    
    curl_close($ch);
    
    $debugInfo['代理HTTP状态'] = $httpCode;
    $debugInfo['cURL错误号'] = $curlErrno;
    
    if ($curlError) {
        $debugInfo['cURL错误'] = $curlError;
        $debugInfo['cURL详细日志'] = $verboseLog;
        
        // 针对不同错误给出友好提示
        $errorMessage = '代理请求失败: ' . $curlError;
        if ($curlErrno == 6) { // CURLE_COULDNT_RESOLVE_HOST
            $errorMessage = '无法解析域名，请检查：1. 服务器DNS配置 2. 能否访问外网 3. hosts文件设置';
        } elseif ($curlErrno == 7) { // CURLE_COULDNT_CONNECT
            $errorMessage = '无法连接到服务器，请检查防火墙或端口设置';
        }
        
        return ['success' => false, 'error' => $errorMessage];
    }
    
    if ($httpCode !== 200) {
        return ['success' => false, 'error' => "代理返回HTTP {$httpCode}"];
    }
    
    $data = json_decode($response, true);
    $debugInfo['代理响应'] = $data ? 'JSON解析成功' : 'JSON解析失败';
    
    if (!$data) {
        $debugInfo['原始响应'] = substr($response, 0, 500); // 只记录前500字符
    }
    
    return $data;
}

// 格式化数字（如果qun_parser.php中没有这个函数，就定义一下）
if (!function_exists('formatNumber')) {
    function formatNumber($num) {
        return number_format($num);
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QQ群信息解析</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            min-height: 100vh;
            padding: 20px;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
        }
        
        .header {
            text-align: center;
            color: white;
            margin-bottom: 30px;
        }
        
        .header h1 {
            font-size: 2.5em;
            margin-bottom: 10px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.2);
        }
        
        .header p {
            font-size: 1.1em;
            opacity: 0.9;
        }
        
        .domain-info {
            background: rgba(255,255,255,0.1);
            padding: 8px 15px;
            border-radius: 20px;
            display: inline-block;
            margin-top: 10px;
            font-size: 14px;
        }
        
        .card {
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            overflow: hidden;
            margin-bottom: 20px;
        }
        
        .card-header {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white;
            padding: 20px;
            font-size: 1.3em;
            font-weight: 500;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .card-body {
            padding: 30px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #333;
        }
        
        .form-control {
            width: 100%;
            padding: 15px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            font-size: 14px;
            transition: all 0.3s;
        }
        
        .form-control:focus {
            border-color: #1e3c72;
            outline: none;
            box-shadow: 0 0 0 3px rgba(30, 60, 114, 0.1);
        }
        
        .btn {
            padding: 15px 30px;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s;
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white;
            width: 100%;
        }
        
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 30px rgba(30, 60, 114, 0.4);
        }
        
        .btn:active {
            transform: translateY(0);
        }
        
        .btn-sm {
            padding: 8px 16px;
            font-size: 14px;
            width: auto;
            display: inline-block;
            background: #1e3c72;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            margin-right: 10px;
        }
        
        .btn-sm:hover {
            background: #2a5298;
        }
        
        .error-message {
            background: #fee;
            color: #c33;
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
            border-left: 4px solid #c33;
        }
        
        .success-message {
            background: #e8f5e9;
            color: #2e7d32;
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
            border-left: 4px solid #2e7d32;
        }
        
        .debug-info {
            background: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 20px;
            font-size: 12px;
        }
        
        .debug-info h4 {
            color: #495057;
            margin-bottom: 10px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .debug-content {
            display: none;
            background: #e9ecef;
            padding: 10px;
            border-radius: 5px;
            overflow-x: auto;
            max-height: 400px;
        }
        
        .debug-content.show {
            display: block;
        }
        
        .system-check {
            background: #e8f4fd;
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
            border-left: 4px solid #2196f3;
        }
        
        .system-check-item {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 8px;
        }
        
        .system-check-item .label {
            font-weight: bold;
            min-width: 100px;
            color: #555;
        }
        
        .system-check-item .value {
            color: #333;
            word-break: break-all;
        }
        
        .system-check-item .status {
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 12px;
            background: #4caf50;
            color: white;
        }
        
        .link-length-info {
            background: #e8f5e9;
            padding: 10px;
            border-radius: 8px;
            margin-top: 10px;
            font-size: 13px;
            border-left: 4px solid #4caf50;
        }
        
        .result-container {
            margin-top: 30px;
        }
        
        .group-info {
            display: flex;
            gap: 30px;
            margin-bottom: 30px;
            padding: 20px;
            background: #f9f9f9;
            border-radius: 15px;
        }
        
        .group-avatar {
            flex-shrink: 0;
            width: 120px;
            height: 120px;
            border-radius: 50%;
            overflow: hidden;
            border: 4px solid white;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        
        .group-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .group-details {
            flex: 1;
        }
        
        .group-details h2 {
            font-size: 24px;
            margin-bottom: 10px;
            color: #333;
        }
        
        .group-meta {
            display: flex;
            gap: 20px;
            margin-bottom: 15px;
            flex-wrap: wrap;
        }
        
        .group-meta-item {
            background: white;
            padding: 8px 15px;
            border-radius: 20px;
            font-size: 14px;
            color: #666;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        }
        
        .group-meta-item strong {
            color: #1e3c72;
            margin-right: 5px;
        }
        
        .group-description {
            background: white;
            padding: 15px;
            border-radius: 10px;
            border-left: 4px solid #1e3c72;
            color: #555;
            line-height: 1.6;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: transparent;
            padding: 10px;
            text-align: center;
            box-shadow: none;
            border-radius: 0;
        }
        
        .stat-header {
            font-size: 14px;
            color: #888;
            margin-bottom: 8px;
        }
        
        .stat-percent {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 5px;
        }
        
        .stat-progress-bg {
            height: 6px;
            background: #f0f0f0;
            border-radius: 3px;
            overflow: hidden;
            width: 80%;
            margin: 0 auto;
        }
        
        .stat-progress-fill {
            height: 100%;
            border-radius: 3px;
        }
        
        @media (max-width: 768px) {
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }
        
        .members-section {
            margin-top: 30px;
            border-top: 2px solid #f0f0f0;
            padding-top: 30px;
        }
        
        .members-section h3 {
            font-size: 18px;
            margin-bottom: 15px;
            color: #333;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .qq-badge {
            background: #1e3c72;
            color: white;
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 12px;
        }
        
        .avatar-grid {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            margin-bottom: 30px;
        }
        
        .avatar-card {
            width: 100px;
            background: white;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            transition: transform 0.3s;
        }
        
        .avatar-card:hover {
            transform: translateY(-5px);
        }
        
        .avatar-card .avatar-img {
            width: 100px;
            height: 100px;
            overflow: hidden;
        }
        
        .avatar-card .avatar-img img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .avatar-card .avatar-info {
            padding: 8px;
            background: #f9f9f9;
            border-top: 1px solid #eee;
            text-align: center;
        }
        
        .avatar-card .qq-number {
            font-size: 11px;
            font-weight: bold;
            color: #333;
            word-break: break-all;
        }
        
        .raw-json {
            margin-top: 30px;
        }
        
        .raw-json pre {
            background: #f5f5f5;
            padding: 15px;
            border-radius: 10px;
            overflow-x: auto;
            font-size: 12px;
            line-height: 1.4;
            border: 1px solid #e0e0e0;
            max-height: 400px;
        }
        
        /* 苹果液态玻璃风格小框框 */
        .glass-mini-card {
            background: linear-gradient(135deg, rgba(255,255,255,0.4) 0%, rgba(255,255,255,0.2) 100%);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border: 1px solid rgba(255,255,255,0.5);
            border-radius: 24px;
            padding: 24px;
            margin: 30px 0;
            box-shadow: 
                0 8px 32px rgba(0, 0, 0, 0.1),
                inset 0 1px 0 rgba(255, 255, 255, 0.6),
                0 0 0 1px rgba(255, 255, 255, 0.1);
            display: flex;
            gap: 24px;
            position: relative;
            overflow: hidden;
        }
        
        .glass-mini-card::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.3) 0%, transparent 50%);
            pointer-events: none;
            animation: glassShine 8s ease-in-out infinite;
        }
        
        @keyframes glassShine {
            0%, 100% { transform: translate(0, 0) rotate(0deg); }
            50% { transform: translate(20%, 20%) rotate(180deg); }
        }
        
        .glass-avatar {
            flex-shrink: 0;
            width: 80px;
            height: 80px;
            border-radius: 50%;
            overflow: hidden;
            border: 3px solid rgba(255, 255, 255, 0.6);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            position: relative;
            z-index: 1;
        }
        
        .glass-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .glass-info {
            flex: 1;
            display: flex;
            flex-direction: column;
            gap: 10px;
            position: relative;
            z-index: 1;
        }
        
        .glass-info-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 8px 14px;
            background: rgba(255, 255, 255, 0.25);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-radius: 12px;
            border: 1px solid rgba(255, 255, 255, 0.4);
            transition: all 0.3s ease;
        }
        
        .glass-info-item:hover {
            background: rgba(255, 255, 255, 0.45);
            transform: translateX(4px);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }
        
        .glass-info-item.full-width {
            flex-direction: column;
            align-items: flex-start;
            gap: 6px;
        }
        
        .glass-info-label {
            font-size: 12px;
            color: #666;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .glass-info-value {
            font-size: 14px;
            color: #1e3c72;
            font-weight: 600;
            word-break: break-all;
            text-align: right;
            max-width: 60%;
        }
        
        .glass-info-item.full-width .glass-info-value {
            text-align: left;
            color: #333;
            font-weight: 500;
            line-height: 1.5;
            max-width: 100%;
        }
        
        .glass-tags {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            margin-top: 8px;
        }
        
        .glass-tag {
            display: inline-block;
            padding: 6px 14px;
            background: linear-gradient(135deg, rgba(30, 60, 114, 0.15) 0%, rgba(42, 82, 152, 0.15) 100%);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border: 1px solid rgba(30, 60, 114, 0.3);
            border-radius: 16px;
            font-size: 13px;
            color: #1e3c72;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        
        .glass-tag:hover {
            background: linear-gradient(135deg, rgba(30, 60, 114, 0.25) 0%, rgba(42, 82, 152, 0.25) 100%);
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(30, 60, 114, 0.2);
        }
        
        @media (max-width: 600px) {
            .glass-mini-card {
                flex-direction: column;
                align-items: center;
                text-align: center;
            }
            
            .glass-info {
                width: 100%;
            }
            
            .glass-info-item {
                flex-direction: column;
                align-items: flex-start;
                gap: 6px;
            }
            
            .glass-info-value {
                text-align: left;
                max-width: 100%;
            }
            
            .glass-info-item.full-width {
                flex-direction: column;
                align-items: flex-start;
            }
        }
        
        .example-link {
            background: #e3f2fd;
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
            font-size: 12px;
            word-break: break-all;
            border-left: 4px solid #2196f3;
        }
        
        .example-link a {
            color: #1976d2;
            text-decoration: none;
        }
        
        .example-link a:hover {
            text-decoration: underline;
        }
        
        .footer {
            text-align: center;
            color: white;
            margin-top: 30px;
            opacity: 0.8;
            font-size: 14px;
        }
        
        .troubleshoot-box {
            background: #fff3e0;
            border: 1px solid #ffe0b2;
            border-radius: 10px;
            padding: 15px;
            margin-top: 20px;
        }
        
        .troubleshoot-box h4 {
            color: #e65100;
            margin-bottom: 10px;
        }
        
        .troubleshoot-box ul {
            margin-left: 20px;
            color: #555;
        }
        
        .troubleshoot-box li {
            margin-bottom: 5px;
        }
        
        .quick-actions {
            display: flex;
            gap: 10px;
            margin-top: 15px;
            flex-wrap: wrap;
        }
        
        .quick-link {
            background: #f0f0f0;
            padding: 8px 15px;
            border-radius: 20px;
            font-size: 12px;
            color: #333;
            text-decoration: none;
            transition: all 0.3s;
        }
        
        .quick-link:hover {
            background: #1e3c72;
            color: white;
        }
        
        .link-info {
            background: #f9f9f9;
            padding: 15px;
            border-radius: 10px;
            margin: 10px 0;
            border-left: 4px solid #1e3c72;
        }
        
        .link-info-item {
            margin-bottom: 8px;
            font-size: 13px;
        }
        
        .link-info-item .label {
            font-weight: bold;
            color: #555;
            min-width: 80px;
            display: inline-block;
        }
        
        .link-info-item .value {
            color: #1e3c72;
            word-break: break-all;
        }
        
        @media (max-width: 768px) {
            .group-info {
                flex-direction: column;
                align-items: center;
                text-align: center;
            }
            
            .group-meta {
                justify-content: center;
            }
            
            .stats-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🐧 QQ群信息解析</h1>
            <p>制作:冷月笙寒</p>
            <div class="domain-info">
                🌐 当前域名: <?php echo htmlspecialchars($host); ?>
            </div>
        </div>
        
        <div class="card">
            <div class="card-header">
                🔗 输入QQ群分享链接
            </div>
            <div class="card-body">
                <div class="system-check">
                    <div class="system-check-item">
                        <span class="label">代理文件:</span>
                        <span class="value"><?php echo htmlspecialchars($baseUrl . 'proxy.php'); ?></span>
                        <span class="status">✓ 已就绪</span>
                    </div>
                    <div class="system-check-item">
                        <span class="label">参数提取:</span>
                        <span class="value"><?php echo htmlspecialchars($baseUrl . 'get_params.php'); ?></span>
                        <span class="status">✓ 已加载</span>
                    </div>
                    <div class="system-check-item">
                        <span class="label">解析器文件:</span>
                        <span class="value"><?php echo htmlspecialchars($baseUrl . 'qun_parser.php'); ?></span>
                        <span class="status">✓ 已加载</span>
                    </div>
                    <div class="system-check-item">
                        <span class="label">加载时间:</span>
                        <span class="value"><?php echo date('Y-m-d H:i:s'); ?></span>
                    </div>
                </div>
                
                <div class="example-link">
                    <strong>📌 规则：</strong><br>
                    • 链接获取可去QQ中点击分享群复制加群链接(注:请去除中文信息)<br>
                    • 示例短链接: <code>https://qm.qq.com/q/xxxxxxxxxx</code> (长度 31)<br>
                    • 示例长链接: <code>https://qun.qq.com/universal-share/share?ac=1&authKey=xxx&busi_data=xxx&data=xxx</code> (长度 > 100)
                </div>
                
                <form method="POST">
                    <div class="form-group">
                        <label for="qun_url">QQ群分享链接</label>
                        <input type="url" name="qun_url" id="qun_url" class="form-control" 
                               placeholder="例如：https://qm.qq.com/q/xxx 或 https://qun.qq.com/universal-share/share?..." 
                               value="<?php echo htmlspecialchars($qunUrl); ?>" 
                               required>
                    </div>
                    
                    <div id="linkLengthHint" class="link-length-info" style="display: none;">
                        📏 链接长度: <span id="linkLength">0</span> | 
                        类型: <span id="linkType">未知</span>
                    </div>
                    
                    <button type="submit" class="btn">🚀 一键获取群信息</button>
                </form>
                
                <div class="quick-actions">
                    <span style="color: #666; font-size: 13px; line-height: 32px;">快速测试：</span>
                    <a href="javascript:void(0)" onclick="fillExampleShortLink()" class="quick-link">🔗 填入短链接示例</a>
                    <a href="javascript:void(0)" onclick="fillExampleLongLink()" class="quick-link">📋 填入长链接示例</a>
                    <a href="javascript:void(0)" onclick="testProxy()" class="quick-link">🔄 测试代理</a>
                    <?php if (!empty($debugInfo)): ?>
                    <a href="javascript:void(0)" onclick="toggleDebug()" class="quick-link">🔧 查看调试信息</a>
                    <?php endif; ?>
                </div>
                
                <?php if (!empty($debugInfo)): ?>
                <div id="debugContent" class="debug-content">
                    <pre><?php echo htmlspecialchars(print_r($debugInfo, true)); ?></pre>
                </div>
                <?php endif; ?>
                
                <div id="testResult" style="margin-top: 10px;"></div>
                
                <?php if ($error): ?>
                <div class="error-message">
                    ❌ <?php echo htmlspecialchars($error); ?>
                    
                    <?php if (strpos($error, 'DNS') !== false || strpos($error, 'resolve') !== false): ?>
                    <div class="troubleshoot-box">
                        <h4>🔧 DNS解析问题排查步骤：</h4>
                        <ul>
                            <li>1. 检查服务器能否访问外网：<code>ping qq.com</code></li>
                            <li>2. 检查DNS配置：<code>cat /etc/resolv.conf</code> (Linux)</li>
                            <li>3. 尝试使用Google DNS：修改 <code>/etc/resolv.conf</code> 添加 <code>nameserver 8.8.8.8</code></li>
                            <li>4. 检查hosts文件：<code>127.0.0.1 localhost</code> 是否存在</li>
                            <li>5. 如果是本地环境，尝试使用IP访问而不是域名</li>
                        </ul>
                    </div>
                    <?php endif; ?>
                    
                    <?php if (strpos($error, '参数') !== false): ?>
                    <div class="troubleshoot-box">
                        <h4>🔗 链接格式问题：</h4>
                        <ul>
                            <li>1. 确保链接包含 <code>authKey</code>、<code>busi_data</code>、<code>data</code> 参数</li>
                            <li>2. 链接应该是从QQ复制的分享链接，不是浏览器地址栏的URL</li>
                            <li>3. 可以尝试重新从QQ复制链接</li>
                        </ul>
                    </div>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
                
                <?php if ($result && !$error): ?>
                <div class="success-message">
                    ✅ 解析成功！已获取群信息
                </div>
                <?php endif; ?>
            </div>
        </div>
        
        <?php if ($result): ?>
        <div class="result-container">
            <div class="card">
                <div class="card-header">
                    📊 群信息解析结果
                    <span class="qq-badge">QQ号: <?php echo count($result['member_qqs']); ?>个</span>
                </div>
                <div class="card-body">
                    <!-- 链接信息（如果是短链接解析的） -->
                    <?php if (isset($result['short_url']) && isset($result['long_url'])): ?>
                    <div class="link-info">
                        <div class="link-info-item">
                            <span class="label">短链接:</span>
                            <span class="value"><?php echo htmlspecialchars($result['short_url']); ?></span>
                        </div>
                        <div class="link-info-item">
                            <span class="label">长链接:</span>
                            <span class="value"><?php echo htmlspecialchars($result['long_url']); ?></span>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <!-- 群基本信息 -->
                    <div class="group-info">
                        <?php if ($result['group_avatar']): ?>
                        <div class="group-avatar">
                            <img src="<?php echo htmlspecialchars($result['group_avatar']); ?>" alt="群头像">
                        </div>
                        <?php endif; ?>
                        
                        <div class="group-details">
                            <h2><?php echo htmlspecialchars($result['group_name'] ?: '未知群名'); ?></h2>
                            
                            <div class="group-meta">
                                <?php if ($result['group_code']): ?>
                                <span class="group-meta-item"><strong>群号</strong> <?php echo htmlspecialchars($result['group_code']); ?></span>
                                <?php endif; ?>
                                
                                <?php if ($result['member_count'] > 0): ?>
                                <span class="group-meta-item"><strong>成员</strong> <?php echo formatNumber($result['member_count']); ?>人</span>
                                <?php endif; ?>
                                
                                <?php if ($result['create_time']): ?>
                                <span class="group-meta-item"><strong>创建于</strong> <?php echo htmlspecialchars($result['create_time']); ?></span>
                                <?php endif; ?>
                            </div>
                            
                            <?php if ($result['description']): ?>
                            <div class="group-description">
                                <strong>📝 群介绍：</strong><br>
                                <?php echo nl2br(htmlspecialchars($result['description'])); ?>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <!-- 活动数据 -->
                    <?php if (!empty($result['activity'])): ?>
                    <h3 style="margin-bottom: 15px; color: #333;">📈 群活跃度统计</h3>
                    <div class="stats-grid">
                        <?php foreach ($result['activity'] as $activity): ?>
                        <?php
                            $title = $activity['title'];
                            $percent = $activity['percentage'];
                            $count = formatNumber($activity['count']);
                            
                            // 默认样式
                            $color = '#9c27b0'; // 紫色
                            $icon = '📍';
                            
                            if (strpos($title, '活跃') !== false) {
                                $color = '#ff5722'; // 橙红色
                                $icon = '🔥';
                            } elseif (strpos($title, '男') !== false) {
                                $color = '#2196f3'; // 蓝色
                                $icon = '♂';
                            } elseif (strpos($title, '女') !== false) {
                                $color = '#e91e63'; // 粉色
                                $icon = '♀';
                            } elseif (preg_match('/^\d+后/', $title)) {
                                $color = '#00bcd4'; // 青色
                                $icon = '👤';
                            } elseif (strpos($title, '朝阳') !== false) { // 示例中出现的朝阳，给个紫色
                                $color = '#9c27b0';
                                $icon = '📍'; // 或者 🏠
                            }
                        ?>
                        <div class="stat-card">
                            <div class="stat-header"><?php echo htmlspecialchars($title); ?> <?php echo $count; ?>人</div>
                            <div class="stat-percent" style="color: <?php echo $color; ?>">
                                <?php echo $icon; ?><?php echo $percent; ?>%
                            </div>
                            <div class="stat-progress-bg">
                                <div class="stat-progress-fill" style="width: <?php echo $percent; ?>%; background-color: <?php echo $color; ?>; opacity: 0.8;"></div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                    
                    <!-- 成员头像部分 -->
                    <?php if (!empty($result['member_qqs'])): ?>
                    <div class="members-section">
                        <h3>
                            👥 提取的QQ号 (<?php echo count($result['member_qqs']); ?>个)
                            <span class="qq-badge">使用 q2.qlogo.cn 接口</span>
                        </h3>
                        
                        <div class="avatar-grid">
                            <?php foreach (array_slice($result['member_qqs'], 0, 12) as $qq): ?>
                            <?php $avatarUrl = getQQAvatarUrl($qq, 100); ?>
                            <div class="avatar-card">
                                <div class="avatar-img">
                                    <img src="<?php echo htmlspecialchars($avatarUrl); ?>" 
                                         alt="QQ头像" 
                                         onerror="this.src='https://q2.qlogo.cn/headimg_dl?dst_uin=0&spec=100'">
                                </div>
                                <div class="avatar-info">
                                    <div class="qq-number"><?php echo htmlspecialchars($qq); ?></div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        
                        <?php if (count($result['member_qqs']) > 12): ?>
                        <p style="text-align: center; color: #666; margin-top: 10px;">... 共 <?php echo count($result['member_qqs']); ?> 个QQ号</p>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                    
                    <!-- 苹果液态玻璃风格小框框 -->
                    <div class="glass-mini-card">
                        <?php if ($result['group_avatar']): ?>
                        <div class="glass-avatar">
                            <img src="<?php echo htmlspecialchars($result['group_avatar']); ?>" alt="群头像">
                        </div>
                        <?php endif; ?>
                        <div class="glass-info">
                            <div class="glass-info-item">
                                <span class="glass-info-label">群名称</span>
                                <span class="glass-info-value"><?php echo htmlspecialchars($result['group_name'] ?: '未知群名'); ?></span>
                            </div>
                            <div class="glass-info-item">
                                <span class="glass-info-label">群号</span>
                                <span class="glass-info-value"><?php echo htmlspecialchars($result['group_code'] ?: '-'); ?></span>
                            </div>
                            <div class="glass-info-item">
                                <span class="glass-info-label">成员数</span>
                                <span class="glass-info-value"><?php echo $result['member_count'] ? formatNumber($result['member_count']) . ' 人' : '-'; ?></span>
                            </div>
                            <div class="glass-info-item">
                                <span class="glass-info-label">创建时间</span>
                                <span class="glass-info-value"><?php echo htmlspecialchars($result['create_time'] ?: '-'); ?></span>
                            </div>
                            <?php if ($result['description']): ?>
                            <div class="glass-info-item full-width">
                                <span class="glass-info-label">群介绍</span>
                                <span class="glass-info-value"><?php echo htmlspecialchars($result['description']); ?></span>
                            </div>
                            <?php endif; ?>
                            <?php if (!empty($result['tags'])): ?>
                            <div class="glass-info-item full-width">
                                <span class="glass-info-label">标签</span>
                                <div class="glass-tags">
                                    <?php foreach ($result['tags'] as $tag): ?>
                                    <span class="glass-tag"><?php echo htmlspecialchars($tag); ?></span>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <!-- 解析结果预览 -->
                    <div class="raw-json">
                        <h3 style="margin-bottom: 10px; color: #333;">📋 解析结果预览</h3>
                        <pre><?php 
                        echo htmlspecialchars(json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)); 
                        ?></pre>
                    </div>
                    
                    <!-- 重新解析按钮 -->
                    <div style="margin-top: 20px; text-align: center;">
                        <a href="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" class="btn-sm">🔄 解析新的群</a>
                        <?php if (isset($result['short_url']) || isset($result['long_url'])): ?>
                        <button id="joinGroupBtn" class="btn-sm" style="background: linear-gradient(135deg, #12b7f5 0%, #0056d2 100%);"
                                data-group-url="<?php echo isset($result['short_url']) ? htmlspecialchars($result['short_url']) : htmlspecialchars($result['long_url']); ?>">
                            🐧 点击加群
                        </button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
        
        <div class="footer">
            <p>QQ群信息解析器 | 制作:冷月笙寒 | 自动判断短链接/长链接</p>
        </div>
    </div>

    <!-- 隐藏的 iframe 用于加载加群链接 -->
    <iframe id="joinGroupIframe" style="display: none; width: 0; height: 0; border: none;"></iframe>

    <script>
        function toggleDebug() {
            var debugContent = document.getElementById('debugContent');
            if (debugContent) {
                debugContent.classList.toggle('show');
            }
        }
        
        function testProxy() {
            var testResult = document.getElementById('testResult');
            testResult.innerHTML = '⏳ 正在测试代理文件...';
            testResult.style.color = '#666';
            
            fetch('proxy.php?test=1')
                .then(response => {
                    if (response.ok) {
                        return response.text();
                    }
                    throw new Error('HTTP ' + response.status);
                })
                .then(data => {
                    testResult.innerHTML = '✅ 代理文件可访问！返回内容长度: ' + data.length + ' 字符';
                    testResult.style.color = 'green';
                })
                .catch(error => {
                    testResult.innerHTML = '❌ 代理文件不可访问: ' + error.message;
                    testResult.style.color = 'red';
                });
        }
        
        function fillExampleShortLink() {
            var input = document.getElementById('qun_url');
            input.value = 'https://qm.qq.com/q/xxxxxxxxxx';
            input.focus();
            updateLinkLength();
        }
        
        function fillExampleLongLink() {
            var input = document.getElementById('qun_url');
            input.value = ' https://qun.qq.com/universal-share/share?ac=1&authKey=xxx&busi_data=xxx&data=xxx';
            input.focus();
            updateLinkLength();
        }
        
        function updateLinkLength() {
            var input = document.getElementById('qun_url');
            var hint = document.getElementById('linkLengthHint');
            var lengthSpan = document.getElementById('linkLength');
            var typeSpan = document.getElementById('linkType');
            
            if (input.value.length > 0) {
                var length = input.value.length;
                lengthSpan.textContent = length;
                
                if (length < 100) {
                    typeSpan.textContent = '短链接';
                    typeSpan.style.color = '#4caf50';
                } else {
                    typeSpan.textContent = '长链接';
                    typeSpan.style.color = '#2196f3';
                }
                
                hint.style.display = 'block';
            } else {
                hint.style.display = 'none';
            }
        }
        
        // 监听输入框变化
        document.getElementById('qun_url').addEventListener('input', updateLinkLength);

        // 页面加载时检查已有链接
        window.addEventListener('load', updateLinkLength);

        // 加群按钮点击事件
        var joinGroupBtn = document.getElementById('joinGroupBtn');
        if (joinGroupBtn) {
            joinGroupBtn.addEventListener('click', function() {
                var iframe = document.getElementById('joinGroupIframe');
                var groupUrl = this.getAttribute('data-group-url');

                if (groupUrl) {
                    // 检测是否为移动设备
                    var isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);

                    if (isMobile) {
                        // 手机版直接跳转
                        window.location.href = groupUrl;
                        console.log('移动设备，直接跳转:', groupUrl);
                    } else {
                        // PC版使用隐藏iframe
                        iframe.src = groupUrl;
                        console.log('PC设备，通过隐藏iframe加载:', groupUrl);
                    }
                } else {
                    alert('未找到加群链接！');
                }
            });
        }
    </script>
</body>
</html>